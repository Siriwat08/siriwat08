Place these files as follows:
- appscript.gs -> Google Apps Script project (set Script Properties: SPREADSHEET_ID, FOLDER_ID, ALLOWED_ORIGIN)
- index.html, register.html, start.html, end.html -> GitHub Pages repo (enable Pages)

Remember to deploy GAS as Web App (Execute as: Me, Who has access: Anyone) and use the Web app URL in the HTML files.
